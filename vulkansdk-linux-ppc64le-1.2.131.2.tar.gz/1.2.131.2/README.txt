The release notes and getting started guide for this SDK is located online at: https://vulkan.lunarg.com/doc/sdk

Most recent version of release notes: https://vulkan.lunarg.com/doc/sdk/latest/linux/release_notes.html

Most recent version of getting started guide: https://vulkan.lunarg.com/doc/sdk/latest/linux/getting_started.html
