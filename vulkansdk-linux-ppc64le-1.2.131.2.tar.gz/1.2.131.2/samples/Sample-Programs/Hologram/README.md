This demo demonstrates multi-thread command buffer recording.
