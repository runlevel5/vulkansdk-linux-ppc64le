# Codegen
Certain utility and set up code will be reused in multiple samples.  Rather
than duplicate this code in each sample, *future* plans include developing
a codegen capability that will substitute this utility code into sample(s)
at build time.  More details will be provided as this develops.

